			<footer class="footer text-center"> 2017 &copy; Coffee-Ms </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->


    

    
</body>

</html>